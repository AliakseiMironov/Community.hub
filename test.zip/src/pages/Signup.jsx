import React from "react";
import AuthCard from "../components/AuthCard";
import SignupForm from "./SignupForm";

const Signup = () => <AuthCard title="Регистрация"><SignupForm /></AuthCard>;

export default Signup;