import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Button } from "react-bootstrap";
import AuthLayout from "../components/AuthLayout";
import "../styles/forms.css";

const Signup = () => {
  const [formData, setFormData] = useState({ lastName: "", firstName: "", email: "", password: "" });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let newErrors = {};

    if (!formData.lastName.trim()) newErrors.lastName = "Введите фамилию";
    if (!formData.firstName.trim()) newErrors.firstName = "Введите имя";
    if (!formData.email.trim()) {
      newErrors.email = "Введите email";
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = "Некорректный email";
    }

    if (!formData.password) {
      newErrors.password = "Введите пароль";
    } else if (!/(?=.*[A-Z])(?=.*\d).{8,}/.test(formData.password)) {
      newErrors.password = "Пароль должен содержать минимум 8 символов, 1 заглавную букву и 1 цифру";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    localStorage.setItem("userData", JSON.stringify(formData));
    localStorage.setItem("isAuthenticated", "true");
    navigate("/profile");
  };

  return (
    <AuthLayout>
      <div className="auth-form">
        <h3 className="text-center fw-bold">Регистрация</h3>
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Фамилия</Form.Label>
            <Form.Control
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              className={errors.lastName ? "error-input" : ""}
            />
            {errors.lastName && <p className="error-text">{errors.lastName}</p>}
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Имя</Form.Label>
            <Form.Control
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              className={errors.firstName ? "error-input" : ""}
            />
            {errors.firstName && <p className="error-text">{errors.firstName}</p>}
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? "error-input" : ""}
            />
            {errors.email && <p className="error-text">{errors.email}</p>}
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Пароль</Form.Label>
            <Form.Control
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className={errors.password ? "error-input" : ""}
            />
            {errors.password && <p className="error-text">{errors.password}</p>}
          </Form.Group>

          <Button className="w-100 auth-button" type="submit">Создать аккаунт</Button>
        </Form>
        <div className="text-center mt-3">
          <p>Уже есть аккаунт? <Link to="/login">Войти</Link></p>
        </div>
      </div>
    </AuthLayout>
  );
};

export default Signup;
