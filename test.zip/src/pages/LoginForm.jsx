import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Button, InputGroup } from "react-bootstrap";
import { Eye, EyeSlash } from "react-bootstrap-icons";
import AuthLayout from "../components/AuthLayout";
import "../styles/forms.css";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let newErrors = {};
    const savedUser = JSON.parse(localStorage.getItem("userData"));

    if (!formData.email) newErrors.email = "Введите email";
    if (!formData.password) newErrors.password = "Введите пароль";
    if (!savedUser || savedUser.email !== formData.email || savedUser.password !== formData.password) {
      newErrors.general = "Неверный email или пароль";
    }

    if (Object.keys(newErrors).length === 0) {
      localStorage.setItem("isAuthenticated", "true");
      navigate("/profile");
    } else {
      setErrors(newErrors);
    }
  };

  return (
    <AuthLayout>
      <div className="auth-form">
        <h3 className="text-center fw-bold">Войти</h3>
        <Form onSubmit={handleSubmit}>
          {errors.general && <p className="error-text text-center">{errors.general}</p>}
          <Form.Group className="mb-3">
            <Form.Label>E-mail</Form.Label>
            <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Пароль</Form.Label>
            <InputGroup>
              <Form.Control type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} />
              <Button variant="link" onClick={() => setShowPassword(!showPassword)}>
                {showPassword ? <EyeSlash /> : <Eye />}
              </Button>
            </InputGroup>
          </Form.Group>
          <Button className="w-100 auth-button" type="submit">Войти</Button>
        </Form>
        <div className="text-center mt-3">
          <p>Нет аккаунта? <Link to="/signup">Регистрация</Link></p>
          <p><Link to="/forgot">Забыли пароль?</Link></p>
        </div>
      </div>
    </AuthLayout>
  );
};

export default Login;
