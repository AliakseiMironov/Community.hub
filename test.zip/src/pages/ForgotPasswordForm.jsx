import React from "react";
import { Form, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import AuthLayout from "../components/AuthLayout";

const ForgotPasswordForm = () => (
<AuthLayout>  <Form>
    <Form.Group className="mb-3">
      <Form.Label>Email</Form.Label>
      <Form.Control type="email" placeholder="Введите email" />
    </Form.Group>
    <Button variant="warning" className="w-100">Восстановить</Button>
    <div className="text-center mt-3">
      <Link to="/login">Вернуться ко входу</Link>
    </div>
  </Form></AuthLayout>
);

export default ForgotPasswordForm;
