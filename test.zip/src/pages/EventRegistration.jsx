import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Modal } from "react-bootstrap";

const EventRegistration = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({ name: "", date: "", location: "" });
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();

  const handleNext = () => setStep(step + 1);
  const handlePrev = () => setStep(step - 1);
  
  const handleCancel = () => {
    setShowSuccess(false);
    setFormData({ name: "", date: "", location: "" });
  };
  
  const handleSubmit = () => {
    const savedEvents = JSON.parse(localStorage.getItem("events")) || [];
    const updatedEvents = [...savedEvents, formData];
    localStorage.setItem("events", JSON.stringify(updatedEvents));
    setShowSuccess(true);
    setTimeout(() => {
      navigate("/profile");
    }, 2000);
  };

  return (
    <div className="container mt-5">
      <h2>Регистрация мероприятия</h2>
      {step === 1 && <><label>Название:</label><input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required /><Button onClick={handleNext}>Далее</Button></>}
      {step === 2 && <><label>Дата:</label><input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} required /><Button onClick={handlePrev}>Назад</Button><Button onClick={handleNext}>Далее</Button></>}
      {step === 3 && <><label>Место проведения:</label><input type="text" value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} required /><Button onClick={handlePrev}>Назад</Button><Button onClick={handleSubmit}>Завершить</Button></>}

      <Modal show={showSuccess} onHide={handleCancel}>
        <Modal.Body>Мероприятие успешно зарегистрировано!</Modal.Body>
      </Modal>
    </div>
  );
};

export default EventRegistration;
