import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";

const ProfilePage = () => {
  const [events, setEvents] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("isAuthenticated");
    if (!isAuthenticated) navigate("/login");

    const savedEvents = JSON.parse(localStorage.getItem("events")) || [];
    setEvents(savedEvents);
  }, [navigate]);

  const handleAddEvent = () => {
    navigate("/register-event");
  };

  return (
    <div className="container mt-5">
      <h2>Личный кабинет</h2>
      <Button onClick={handleAddEvent} className="mb-3">Добавить мероприятие</Button>
      <ul>
        {events.map((event, index) => (
          <li key={index}>
            <Link to={`/event/${event.id}`}>{event.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProfilePage;
