import React from "react";
import Navigation from "./routes/Navigation"; // Импортируем файл навигации
import "bootstrap/dist/css/bootstrap.min.css";

const App = () => {
  return <Navigation />;
};

export default App;
