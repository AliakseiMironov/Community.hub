import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "../pages/LoginForm";
import Signup from "../pages/SignupForm";
import ProfilePage from "../pages/ProfilePage";
import EventRegistration from "../pages/EventRegistration";
import ForgotPasswordForm from "../pages/ForgotPasswordForm";
import UsersList from "../pages/UsersList";

const PrivateRoute = ({ children }) => {
  const isAuthenticated = localStorage.getItem("isAuthenticated");
  return isAuthenticated ? children : <Navigate to="/login" />;
};

const Navigation = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot" element={<ForgotPasswordForm />} />
        <Route path="/register-event" element={<PrivateRoute><EventRegistration /></PrivateRoute>} />
        <Route path="/profile" element={<PrivateRoute><ProfilePage /></PrivateRoute>} />
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/users" element={<UsersList />} />
      </Routes>
    </Router>
  );
};

export default Navigation;
