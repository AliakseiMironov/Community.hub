import React from "react";
import "../styles/authBackground.css";

const AuthLayout = ({ children }) => {
  return (
    <div className="auth-background">
      <div className="auth-content">{children}</div>
    </div>
  );
};

export default AuthLayout;
