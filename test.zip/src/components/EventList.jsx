import React from "react";
import { Link } from "react-router-dom";

const EventList = ({ events }) => {
  return (
    <ul>
      {events.length === 0 ? <p>Нет мероприятий</p> : events.map((event, index) => (
        <li key={index}>
          <Link to={`/event/${event.id}`}>{event.name}</Link>
        </li>
      ))}
    </ul>
  );
};

export default EventList;
